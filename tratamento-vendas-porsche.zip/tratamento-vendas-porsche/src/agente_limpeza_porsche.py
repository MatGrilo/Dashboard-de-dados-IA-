#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Agente de limpeza da Base de Vendas Porsche (db_psc_..._no_tracked).

Implementa, de forma DETERMINÍSTICA, o contrato de limpeza descrito em schema.md:
- um parser por coluna, com ordem de parsing obrigatória;
- regra "mês > 12 ⇒ ordem dia/mês" para datas;
- sanity checks (faixa de preço, faixa de ano, calendário real, faixa de data);
- QUARENTENA por CAMPO (nunca descarta a linha): campo problemático vira null,
  a linha continua na base limpa e o motivo vai pra tabela `quarentena`;
- preserva as colunas originais (_raw) para auditoria (§2.5).

Uso:
    python3 agente_limpeza_porsche.py <entrada.xlsx> <saida.xlsx>

Gera 4 abas na saída: base_limpa | auditoria | quarentena | relatorio
"""

import re
import sys
import datetime
from collections import Counter, defaultdict
from openpyxl import load_workbook, Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

# ---------------------------------------------------------------------------
# §2 CONVENÇÕES GLOBAIS
# ---------------------------------------------------------------------------

_INVISIBLE = dict.fromkeys(map(ord, ["\u200b", "\ufeff", "\u200c", "\u200d"]), None)

def clean_text(v):
    """Trim universal (§2.4): remove invisíveis, troca NBSP por espaço,
    colapsa espaços internos e faz strip. Retorna '' para None."""
    if v is None:
        return ""
    s = str(v)
    s = s.replace("\u00a0", " ").translate(_INVISIBLE)
    s = re.sub(r"\s+", " ", s).strip()
    return s

def title_case(s):
    """Title Case preservando hifens (Daniel-Jones) e abreviações (St. Louis)."""
    def cap(tok):
        parts = tok.split("-")
        parts = [p[:1].upper() + p[1:].lower() if p else p for p in parts]
        return "-".join(parts)
    return " ".join(cap(w) for w in clean_text(s).split(" "))

# Números por extenso (para preço/milhagem: "eighty two thousand", "twelve thousand")
_UNITS = {w: i for i, w in enumerate(
    "zero one two three four five six seven eight nine ten eleven twelve "
    "thirteen fourteen fifteen sixteen seventeen eighteen nineteen".split())}
_TENS = {"twenty": 20, "thirty": 30, "forty": 40, "fifty": 50,
         "sixty": 60, "seventy": 70, "eighty": 80, "ninety": 90}
_SCALES = {"hundred": 100, "thousand": 1000, "million": 1_000_000}

def words_to_number(s):
    words = clean_text(s).lower().replace("-", " ").split()
    if not words:
        return None
    total = cur = 0
    for w in words:
        if w in _UNITS:
            cur += _UNITS[w]
        elif w in _TENS:
            cur += _TENS[w]
        elif w == "hundred":
            cur = (cur or 1) * 100
        elif w in _SCALES:
            total += cur * _SCALES[w]
            cur = 0
        else:
            return None
    return total + cur

# ---------------------------------------------------------------------------
# §3.2 sale_date  (coluna mais problemática)
# ---------------------------------------------------------------------------

_MONTHS = {}
for i, name in enumerate(
    ["january", "february", "march", "april", "may", "june", "july",
     "august", "september", "october", "november", "december"], start=1):
    _MONTHS[name] = i
    _MONTHS[name[:3]] = i  # jan, feb, ...

def _build_date(y, m, d):
    """Interpreta ano de 2 dígitos como 20YY e valida o CALENDÁRIO real.
    Retorna (iso, None) ou (None, motivo)."""
    if y < 100:
        y += 2000
    try:
        dt = datetime.date(y, m, d)          # levanta ValueError se dia/mês/bissexto impossível
    except ValueError:
        return None, "data_invalida"
    if not (2024 <= dt.year <= 2027):        # §3.2.5 faixa plausível
        return None, "data_fora_de_faixa"
    return dt.isoformat(), None

def parse_date(cell):
    """Retorna (iso_str | None, motivo | None) seguindo a ordem obrigatória §3.2."""
    # 1) já é serial do Excel / datetime -> pega direto
    if isinstance(cell, datetime.datetime):
        return _build_date(cell.year, cell.month, cell.day)
    if isinstance(cell, datetime.date):
        return _build_date(cell.year, cell.month, cell.day)

    s = clean_text(cell)
    if not s:
        return None, "data_invalida"

    # 2a) Extenso / ordinal: "September 17, 2024", "Dec 25th 2024", "April 31st, 2024"
    m = re.match(r"^([A-Za-z]+)\.?\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})$", s)
    if m and m.group(1).lower() in _MONTHS:
        mon = _MONTHS[m.group(1).lower()]
        return _build_date(int(m.group(3)), mon, int(m.group(2)))

    # 2b) Ano na frente: YYYY[sep]A[sep]B  (ISO, pontuado, e dia-primeiro disfarçado)
    m = re.match(r"^(\d{4})[.\-/](\d{1,2})[.\-/](\d{1,2})$", s)
    if m:
        y, a, b = int(m.group(1)), int(m.group(2)), int(m.group(3))
        # regra "mês > 12 ⇒ ordem dia/mês": se A>12 é dia; senão A é mês
        if a > 12 and b <= 12:
            mon, day = b, a
        else:
            mon, day = a, b
        return _build_date(y, mon, day)

    # 2c) Ano no fim: A[sep]B[sep]YY(YY)  (US MM/DD/YYYY, MM/DD/YY, MM-DD-YY)
    m = re.match(r"^(\d{1,2})[/\-](\d{1,2})[/\-](\d{2,4})$", s)
    if m:
        a, b, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if a > 12 and b <= 12:          # mesma regra do dia/mês por segurança
            mon, day = b, a
        else:
            mon, day = a, b
        return _build_date(y, mon, day)

    return None, "data_invalida"

# ---------------------------------------------------------------------------
# §3.6 sale_price  (mistura formato US e europeu)
# ---------------------------------------------------------------------------

def _price_ok(val):
    """Sanity check §3.6.6: faixa plausível US$ 30.000 – 400.000."""
    if val is None:
        return None, "preco_ambiguo"
    if 30_000 <= val <= 400_000:
        return round(val, 2), None
    return None, "preco_ambiguo"

def parse_price(cell):
    """Retorna (decimal_usd | None, motivo | None) seguindo a ordem §3.6."""
    if isinstance(cell, bool):
        return None, "preco_ambiguo"
    if isinstance(cell, (int, float)):
        return _price_ok(float(cell))

    raw = clean_text(cell).lower()
    # 1) remove rótulos de moeda
    nolabel = re.sub(r"\b(usd|dollars?|dollar)\b", "", raw).replace("$", "").strip()
    compact = nolabel.replace(" ", "")

    # 2) sufixo k / K -> multiplica por 1000
    if compact.endswith("k"):
        num = compact[:-1].replace(",", ".")
        try:
            return _price_ok(float(num) * 1000)
        except ValueError:
            return None, "preco_ambiguo"

    # número com separadores US/EU
    if re.fullmatch(r"[\d.,]+", compact):
        has_dot, has_comma = "." in compact, "," in compact
        try:
            if has_dot and has_comma:
                # 3) separador mais à direita é o decimal
                if compact.rfind(".") > compact.rfind(","):
                    val = float(compact.replace(",", ""))            # ponto decimal
                else:
                    val = float(compact.replace(".", "").replace(",", "."))  # vírgula decimal
            elif has_comma:
                # 4) só vírgula: 3 dígitos após ⇒ milhar; senão decimal
                val = float(compact.replace(",", "")) if len(compact.split(",")[-1]) == 3 \
                      else float(compact.replace(",", "."))
            elif has_dot:
                # 5) só ponto: 3 dígitos após ⇒ milhar EU; senão decimal
                val = float(compact.replace(".", "")) if len(compact.split(".")[-1]) == 3 \
                      else float(compact)
            else:
                val = float(compact)
        except ValueError:
            return None, "preco_ambiguo"
        return _price_ok(val)

    # preço por extenso ("eighty two thousand", "two hundred thousand")
    n = words_to_number(nolabel)
    return _price_ok(float(n)) if n is not None else (None, "preco_ambiguo")

# ---------------------------------------------------------------------------
# §3.7 vehicle_mileage
# ---------------------------------------------------------------------------

_KM_PER_MILE = 1.60934
_ZERO_TOKENS = {"zero", "new", "new car", "zero miles", "0 miles", "0 mi", "0"}

def parse_mileage(cell):
    """Retorna (miles_int | None, unit_raw, suspect_bool)."""
    # inteiro/decimal puro (bruto, sem contexto)
    if isinstance(cell, bool):
        return None, "miles", False
    if isinstance(cell, (int, float)):
        v = float(cell)
        return int(round(v)), "miles", (v < 100)   # §3.7.5 suspeito se < 100

    s = clean_text(cell)
    low = s.lower()

    # 1) zero / new / new car
    if low in _ZERO_TOKENS:
        return 0, "miles", False

    # 2) por extenso ("twelve thousand miles")
    if "thousand" in low or "hundred" in low:
        n = words_to_number(re.sub(r"miles?|mi\.?", "", low))
        if n is not None:
            return n, "miles", (n < 100)

    is_km = "km" in low                     # 4) quilômetros -> converter e registrar
    # 3) remove rótulos/unidades e aplica lógica de milhar (ponto/vírgula)
    t = re.sub(r"miles?:?|mi\.?|km", "", low).replace(" ", "").strip()
    if re.fullmatch(r"[\d.,]+", t) and t:
        val = int(t.replace(".", "").replace(",", ""))
        if is_km:
            return int(round(val / _KM_PER_MILE)), "km", False
        return val, "miles", (val < 100)
    return None, "miles", False

# ---------------------------------------------------------------------------
# §3.5 model_year
# ---------------------------------------------------------------------------

_YEAR_WORDS = {}
for yy, ext in [(2020, "twenty"), (2021, "twenty one"), (2022, "twenty two"),
                (2023, "twenty three"), (2024, "twenty four"),
                (2025, "twenty five"), (2026, "twenty six")]:
    _YEAR_WORDS[f"twenty {ext}"] = yy
    _YEAR_WORDS[f"two thousand {ext}"] = yy
_YEAR_WORDS["twenty twenty"] = 2020

def parse_year(cell):
    """Retorna (int | None, motivo | None). Faixa válida 2020–2026."""
    if isinstance(cell, bool):
        return None, "model_year_invalido"
    if isinstance(cell, (int, float)):
        y = int(cell)
    else:
        s = clean_text(cell).lower()
        digits = re.sub(r"[\s\-]", "", s)               # "20 24"/"20-24" -> "2024"
        if digits.isdigit() and len(digits) == 4:
            y = int(digits)
        else:
            y = _YEAR_WORDS.get(" ".join(s.split()))
            if y is None:
                return None, "model_year_invalido"
    return (y, None) if 2020 <= y <= 2026 else (None, "model_year_invalido")

# ---------------------------------------------------------------------------
# §3.8 payment_method  |  §3.12 delivery_status  (enums)
# ---------------------------------------------------------------------------

def _norm_cat(s):
    """lower + trim + separadores(-,_)->espaço + remove pontuação final + colapsa."""
    s = clean_text(s).lower().replace("-", " ").replace("_", " ")
    s = re.sub(r"[!?.]+$", "", s).strip()
    return re.sub(r"\s+", " ", s)

_PAYMENT = {}
for canon, varis in {
    "cash": ["cash", "cash payment"],
    "credit_card": ["credit card", "creditcard", "credit", "credit card payment"],
    "debit_card": ["debit card"],
    "bank_transfer": ["bank transfer", "bank wire", "wire", "wire transfer",
                      "wiretransfer", "ach payment"],
    "financing": ["financing", "financing plan", "finance"],
    "lease": ["lease", "leasing", "lease plan"],
    "crypto": ["crypto", "crypto payment"],
}.items():
    for v in varis:
        _PAYMENT[_norm_cat(v)] = canon

_DELIVERY = {}
for canon, varis in {
    "delivered": ["delivered", "deliverd"],                       # deliverd = typo
    "in_transit": ["in transit", "shipped"],
    "pending": ["pending", "pending approval", "pending review", "awaiting review"],
    "awaiting": ["awaiting delivery", "awaiting pickup"],
    "cancelled": ["cancelled"],
}.items():
    for v in varis:
        _DELIVERY[_norm_cat(v)] = canon

def parse_payment(cell):
    key = _norm_cat(cell)
    return (_PAYMENT.get(key, "other"),
            None if key in _PAYMENT else "categoria_desconhecida")

def parse_delivery(cell):
    key = _norm_cat(cell)
    return (_DELIVERY.get(key, "unknown"),
            None if key in _DELIVERY else "categoria_desconhecida")

# ---------------------------------------------------------------------------
# §3.10 state  (sigla USPS)
# ---------------------------------------------------------------------------

_USPS = {
    "alabama": "AL", "alaska": "AK", "arizona": "AZ", "arkansas": "AR",
    "california": "CA", "colorado": "CO", "connecticut": "CT", "delaware": "DE",
    "florida": "FL", "georgia": "GA", "hawaii": "HI", "idaho": "ID",
    "illinois": "IL", "indiana": "IN", "iowa": "IA", "kansas": "KS",
    "kentucky": "KY", "louisiana": "LA", "maine": "ME", "maryland": "MD",
    "massachusetts": "MA", "michigan": "MI", "minnesota": "MN",
    "mississippi": "MS", "missouri": "MO", "montana": "MT", "nebraska": "NE",
    "nevada": "NV", "new hampshire": "NH", "new jersey": "NJ",
    "new mexico": "NM", "new york": "NY", "north carolina": "NC",
    "north dakota": "ND", "ohio": "OH", "oklahoma": "OK", "oregon": "OR",
    "pennsylvania": "PA", "rhode island": "RI", "south carolina": "SC",
    "south dakota": "SD", "tennessee": "TN", "texas": "TX", "utah": "UT",
    "vermont": "VT", "virginia": "VA", "washington": "WA",
    "west virginia": "WV", "wisconsin": "WI", "wyoming": "WY",
}
_VALID_ABBR = set(_USPS.values())

def parse_state(cell):
    s = clean_text(cell)
    low = s.lower()
    if low in _USPS:                       # nome completo -> sigla
        return _USPS[low], None
    if s.upper() in _VALID_ABBR:           # já é sigla válida
        return s.upper(), None
    return None, "estado_invalido"

# ---------------------------------------------------------------------------
# §3.4 porsche_model + model_line derivado
# ---------------------------------------------------------------------------

_LINES = ["718", "911", "Taycan", "Panamera", "Macan", "Cayenne"]

def parse_model(cell):
    name = clean_text(cell)
    line = next((l for l in _LINES if l.lower() in name.lower()), None)
    return name, line

# ---------------------------------------------------------------------------
# PIPELINE
# ---------------------------------------------------------------------------

RAW_COLS = ["sale_id", "sale_date", "customer_name", "porsche_model", "model_year",
            "sale_price", "vehicle_mileage", "payment_method", "city", "state",
            "salesperson", "delivery_status"]

CLEAN_COLS = ["sale_id", "sale_date", "customer_name", "porsche_model", "model_line",
              "model_year", "sale_price_usd", "mileage_miles", "mileage_unit_raw",
              "mileage_suspect", "payment_method", "city", "state", "salesperson",
              "delivery_status"]

def run(in_path, out_path):
    wb_in = load_workbook(in_path, data_only=True)
    ws = wb_in.active
    headers = [clean_text(c.value) for c in ws[1]]
    idx = {h: i for i, h in enumerate(headers)}

    rows_raw = []
    for r in range(2, ws.max_row + 1):
        rows_raw.append([ws.cell(row=r, column=idx[c] + 1).value for c in RAW_COLS])

    clean_rows, audit_rows, quarantine, suspects = [], [], [], []
    seen_ids = set()

    for raw in rows_raw:
        rd = dict(zip(RAW_COLS, raw))
        sid = rd["sale_id"]

        # §3.1 sale_id: valida unicidade/nulo (não renumera)
        if sid is None:
            quarantine.append([None, "sale_id", None, "id_nulo"])
        elif sid in seen_ids:
            quarantine.append([sid, "sale_id", sid, "id_duplicado"])
        else:
            seen_ids.add(sid)

        # datas / preço / milhagem / ano
        d_iso, d_reason = parse_date(rd["sale_date"])
        p_val, p_reason = parse_price(rd["sale_price"])
        miles, unit_raw, suspect = parse_mileage(rd["vehicle_mileage"])
        y_val, y_reason = parse_year(rd["model_year"])

        # categóricas
        pay, pay_reason = parse_payment(rd["payment_method"])
        deliv, del_reason = parse_delivery(rd["delivery_status"])
        st, st_reason = parse_state(rd["state"])

        # nominais
        model, line = parse_model(rd["porsche_model"])
        cust = title_case(rd["customer_name"])
        city = title_case(rd["city"])
        sales = title_case(rd["salesperson"])

        # registra quarentenas por CAMPO (não descarta a linha)
        for col, raw_val, reason in [
            ("sale_date", rd["sale_date"], d_reason),
            ("sale_price", rd["sale_price"], p_reason),
            ("model_year", rd["model_year"], y_reason),
            ("payment_method", rd["payment_method"], pay_reason),
            ("delivery_status", rd["delivery_status"], del_reason),
            ("state", rd["state"], st_reason),
        ]:
            if reason:
                quarantine.append([sid, col, clean_text(raw_val) or raw_val, reason])

        if suspect:
            suspects.append(sid)

        clean_rows.append([
            sid, d_iso, cust, model, line, y_val, p_val, miles, unit_raw,
            suspect, pay, city, st, sales, deliv,
        ])
        audit_rows.append([
            sid,
            rd["sale_date"], d_iso,
            rd["sale_price"], p_val,
            rd["vehicle_mileage"], miles, unit_raw, suspect,
            rd["model_year"], y_val,
            rd["payment_method"], pay,
            rd["delivery_status"], deliv,
            rd["state"], st,
            rd["customer_name"], cust,
            rd["city"], city,
            rd["salesperson"], sales,
        ])

    report = _build_report(clean_rows, quarantine, suspects, len(rows_raw))
    _write_workbook(out_path, clean_rows, audit_rows, quarantine, report)
    return report


def _build_report(clean_rows, quarantine, suspects, n_total):
    ci = {c: i for i, c in enumerate(CLEAN_COLS)}
    q_by_col = Counter(q[1] for q in quarantine)
    q_by_reason = Counter(q[3] for q in quarantine)
    ids_afetados = {q[0] for q in quarantine if q[0] is not None}

    dates_ok = sum(1 for r in clean_rows if r[ci["sale_date"]] is not None)
    price_vals = [r[ci["sale_price_usd"]] for r in clean_rows if r[ci["sale_price_usd"]] is not None]
    year_vals = [r[ci["model_year"]] for r in clean_rows if r[ci["model_year"]] is not None]

    pay_card = Counter(r[ci["payment_method"]] for r in clean_rows)
    del_card = Counter(r[ci["delivery_status"]] for r in clean_rows)
    km_count = sum(1 for r in clean_rows if r[ci["mileage_unit_raw"]] == "km")

    linhas_limpas = n_total - len(ids_afetados)

    return {
        "total_linhas": n_total,
        "linhas_100_limpas": linhas_limpas,
        "linhas_com_quarentena": len(ids_afetados),
        "sale_id_unicos": len({r[0] for r in clean_rows}),
        "sale_id_nulos": sum(1 for r in clean_rows if r[0] is None),
        "datas_ok": dates_ok,
        "datas_quarentena": n_total - dates_ok,
        "pct_datas_ok": round(100 * dates_ok / n_total, 1),
        "preco_min": min(price_vals) if price_vals else None,
        "preco_max": max(price_vals) if price_vals else None,
        "preco_fora_faixa": sum(1 for r in clean_rows if r[ci["sale_price_usd"]] is None),
        "ano_fora_faixa": sum(1 for v in year_vals if not (2020 <= v <= 2026)),
        "estados_invalidos": q_by_col.get("state", 0),
        "mileage_km_convertidos": km_count,
        "mileage_suspeitos": len(suspects),
        "ids_suspeitos": suspects,
        "payment_cardinalidade": dict(pay_card),
        "delivery_cardinalidade": dict(del_card),
        "quarentena_por_coluna": dict(q_by_col),
        "quarentena_por_motivo": dict(q_by_reason),
        "payment_other": pay_card.get("other", 0),
        "delivery_unknown": del_card.get("unknown", 0),
    }

# ---------------------------------------------------------------------------
# SAÍDA .xlsx
# ---------------------------------------------------------------------------

_HDR_FILL = PatternFill("solid", fgColor="1F2937")
_HDR_FONT = Font(bold=True, color="FFFFFF", name="Arial", size=10)
_FONT = Font(name="Arial", size=10)
_Q_FILL = PatternFill("solid", fgColor="FDE68A")
_THIN = Side(style="thin", color="D1D5DB")
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)

def _style_header(ws, ncols):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=1, column=c)
        cell.fill, cell.font = _HDR_FILL, _HDR_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = _BORDER
    ws.freeze_panes = "A2"

def _autosize(ws):
    for col in ws.columns:
        width = max((len(str(c.value)) for c in col if c.value is not None), default=8)
        ws.column_dimensions[col[0].column_letter].width = min(max(width + 2, 10), 42)

def _write_workbook(out_path, clean_rows, audit_rows, quarantine, report):
    wb = Workbook()

    # -- base_limpa --
    ws = wb.active
    ws.title = "base_limpa"
    ws.append(CLEAN_COLS)
    for r in clean_rows:
        ws.append([("" if v is None else v) for v in r])
    _style_header(ws, len(CLEAN_COLS))
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.font = _FONT
            if cell.value in ("", None):     # destaca campos quarentenados (null)
                cell.fill = _Q_FILL
    _autosize(ws)

    # -- auditoria (_raw vs limpo, §2.5) --
    ws2 = wb.create_sheet("auditoria")
    audit_hdr = ["sale_id",
                 "sale_date_raw", "sale_date",
                 "sale_price_raw", "sale_price_usd",
                 "vehicle_mileage_raw", "mileage_miles", "mileage_unit_raw", "mileage_suspect",
                 "model_year_raw", "model_year",
                 "payment_method_raw", "payment_method",
                 "delivery_status_raw", "delivery_status",
                 "state_raw", "state",
                 "customer_name_raw", "customer_name",
                 "city_raw", "city",
                 "salesperson_raw", "salesperson"]
    ws2.append(audit_hdr)
    for r in audit_rows:
        ws2.append([("" if v is None else v) for v in r])
    _style_header(ws2, len(audit_hdr))
    for row in ws2.iter_rows(min_row=2):
        for cell in row:
            cell.font = _FONT
    _autosize(ws2)

    # -- quarentena (§6) --
    ws3 = wb.create_sheet("quarentena")
    ws3.append(["sale_id", "column", "raw_value", "reason"])
    for q in quarantine:
        ws3.append([("" if v is None else v) for v in q])
    _style_header(ws3, 4)
    for row in ws3.iter_rows(min_row=2):
        for cell in row:
            cell.font = _FONT
    _autosize(ws3)

    # -- relatorio (§5) --
    ws4 = wb.create_sheet("relatorio")
    ws4.append(["Métrica", "Valor"])
    linhas = [
        ("Linhas totais", report["total_linhas"]),
        ("Linhas 100% limpas", report["linhas_100_limpas"]),
        ("Linhas com >=1 campo quarentenado", report["linhas_com_quarentena"]),
        ("sale_id únicos", report["sale_id_unicos"]),
        ("sale_id nulos", report["sale_id_nulos"]),
        ("Datas parseadas OK", f'{report["datas_ok"]} ({report["pct_datas_ok"]}%)'),
        ("Datas em quarentena", report["datas_quarentena"]),
        ("Preço mínimo (USD)", report["preco_min"]),
        ("Preço máximo (USD)", report["preco_max"]),
        ("Preços fora de faixa (30k–400k)", report["preco_fora_faixa"]),
        ("model_year fora de faixa (2020–2026)", report["ano_fora_faixa"]),
        ("Estados inválidos", report["estados_invalidos"]),
        ("Milhagens convertidas de KM", report["mileage_km_convertidos"]),
        ("mileage_suspect = true", report["mileage_suspeitos"]),
        ("IDs suspeitos (milhagem)", ", ".join(map(str, report["ids_suspeitos"]))),
        ("payment_method 'other' inesperado", report["payment_other"]),
        ("delivery_status 'unknown' inesperado", report["delivery_unknown"]),
    ]
    for k, v in linhas:
        ws4.append([k, ("" if v is None else v)])

    ws4.append([])
    ws4.append(["Quarentena por coluna", ""])
    for k, v in sorted(report["quarentena_por_coluna"].items()):
        ws4.append([f"   {k}", v])
    ws4.append(["Quarentena por motivo", ""])
    for k, v in sorted(report["quarentena_por_motivo"].items()):
        ws4.append([f"   {k}", v])
    ws4.append(["Cardinalidade payment_method", ""])
    for k, v in sorted(report["payment_cardinalidade"].items()):
        ws4.append([f"   {k}", v])
    ws4.append(["Cardinalidade delivery_status", ""])
    for k, v in sorted(report["delivery_cardinalidade"].items()):
        ws4.append([f"   {k}", v])

    _style_header(ws4, 2)
    for row in ws4.iter_rows(min_row=2):
        for cell in row:
            cell.font = _FONT
        if row[0].value and not str(row[0].value).startswith("   ") and row[1].value == "":
            row[0].font = Font(name="Arial", size=10, bold=True)
    _autosize(ws4)

    wb.save(out_path)


if __name__ == "__main__":
    src = sys.argv[1] if len(sys.argv) > 1 else "entrada.xlsx"
    dst = sys.argv[2] if len(sys.argv) > 2 else "base_porsche_limpa.xlsx"
    rep = run(src, dst)
    print("=" * 60)
    print("RELATÓRIO DE LIMPEZA")
    print("=" * 60)
    for k, v in rep.items():
        if not isinstance(v, (dict, list)):
            print(f"  {k:34s}: {v}")
    print("  quarentena_por_motivo             :", rep["quarentena_por_motivo"])
    print("  payment_cardinalidade             :", rep["payment_cardinalidade"])
    print("  delivery_cardinalidade            :", rep["delivery_cardinalidade"])
    print(f"\nSaída gravada em: {dst}")
