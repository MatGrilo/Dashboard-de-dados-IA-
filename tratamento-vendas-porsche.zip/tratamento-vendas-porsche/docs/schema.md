# schema.md — Base de Vendas Porsche (`db_psc_25354543_no_tracked`)

> **Objetivo deste documento:** servir de contrato de limpeza para o agente. Ele descreve, coluna a coluna, o estado bruto dos dados, os problemas reais observados (com exemplos da própria base), o tipo/formato alvo e a regra de transformação. O agente deve seguir estas regras de forma determinística e **quarentenar** (não adivinhar) qualquer valor irrecuperável.

---

## 1. Visão geral

| Item | Valor |
|---|---|
| Nome da aba | `db_psc_25354543_no_tracked` |
| Grão (1 linha =) | 1 venda de veículo |
| Linhas de dados | 100 |
| Colunas | 12 |
| Chave primária | `sale_id` |
| Faixa de `sale_id` | 6 – 105 (sequencial, sem duplicatas, sem buracos) |
| Sufixo `no_tracked` | Indica base bruta/não tratada — é exatamente o que vamos limpar |

**Domínio de negócio (importante para sanity checks):** são carros novos/seminovos Porsche. Preços reais observados vão de ~US$ 58.900 a ~US$ 286.500. Anos de modelo vão de 2020 a 2026. Use essas faixas como âncora ao desambiguar valores.

---

## 2. Convenções globais de saída

1. **Idioma/encoding da saída:** UTF-8.
2. **Nulos:** use `null` (ou `NA`) para valores ausentes. Nunca invente valor.
3. **Estratégia de quarentena:** valores que **não podem** ser recuperados com segurança (ex.: data 30/02, preço ilegível) **não** devem ser "chutados". A linha vai para uma tabela `quarantine` (ver §6) com o motivo, e o campo problemático fica `null` na base limpa — nunca descarte a linha inteira só por causa de um campo.
4. **Trim universal:** remover espaços no início/fim, espaços duplos internos e caracteres invisíveis (zero-width space `U+200B`, NBSP `U+00A0`) de **todo** campo texto antes de qualquer parsing.
5. **Cada regra de normalização deve gerar uma coluna limpa nova** e **preservar a original** (sufixo `_raw`) até a validação final, para permitir auditoria.

---

## 3. Especificação por coluna

### 3.1 `sale_id`
- **Origem:** inteiro.
- **Alvo:** `int`, chave primária.
- **Estado:** limpo. Sequencial 6–105, sem duplicatas, sem nulos.
- **Regra:** validar unicidade e ausência de nulos. Não renumerar (o início em 6 é legítimo).

### 3.2 `sale_date` ⚠️ *(coluna mais problemática)*
- **Origem:** mistura de `string` e serial do Excel (`datetime`).
- **Alvo:** `date` no formato ISO `YYYY-MM-DD`.
- **Problemas observados (todos reais na base):**
  - Serial do Excel já convertido para data (ex.: `45400` → `2024-04-18`).
  - ISO com dia impossível: `2024-02-30`, `2025-09-31`, `2026-06-31`.
  - ISO com dia > 31: `2024-10-40`, `2025-12-40`, `2026-07-35`, `2026-12-38`, `2027-06-40`.
  - US `MM/DD/YYYY` e `MM/DD/YY`: `03/14/2024`, `08/19/24`, `03/28/25`.
  - US com dia impossível: `01/32/2025`, `06/31/2025`, `03/32/2026`, `11/31/2026`.
  - Pontuado `YYYY.MM.DD`: `2024.07.11`, `2026.03.01`.
  - **Dia-primeiro disfarçado** `YYYY/DD/MM`: `2024/15/07` (mês 15 impossível ⇒ é dia 15, mês 07), `2025/18/11`, `2027/15/04`. **Regra:** se o "mês" > 12, então a ordem é dia/mês.
  - `YYYY/MM/DD` com dia impossível: `2025/04/31`.
  - Extenso: `September 17, 2024`, `May 12, 2025`.
  - Ordinal: `Dec 25th 2024`, `July 22nd, 2025`, `Jun 18th 2027`.
  - Ordinal com data impossível: `April 31st, 2024`, `February 30th, 2026`, **`February 29th, 2025`** (2025 não é bissexto).
  - `MM-DD-YY`: `12-22-25`, `05-27-27`.
- **Regra de transformação (ordem obrigatória):**
  1. Se a célula já é `datetime` (serial do Excel), pegue direto a data.
  2. Senão, tente parsear por família de formato, aplicando a regra "mês > 12 ⇒ dia/mês".
  3. Interprete anos de 2 dígitos como `20YY` (`24`→2024, `27`→2027).
  4. **Valide o calendário** (dia real do mês, ano bissexto). Se a data for logicamente impossível ⇒ **não corrija por proximidade**; marque `sale_date = null` e mande a linha para quarentena com motivo `data_invalida`.
  5. Faixa plausível esperada: 2024–2027. Datas fora disso ⇒ quarentena com motivo `data_fora_de_faixa`.

### 3.3 `customer_name`
- **Origem:** `string`. **Alvo:** `string` em Title Case.
- **Problemas:** caixa inconsistente (`SOPHIA Miller`, `michael adams`); hifens (`Daniel-Jones`, `Ryan-Cooper`).
- **Regra:** Title Case preservando o hífen (`Daniel-Jones`). Não separar sobrenomes hifenizados — podem ser legítimos.

### 3.4 `porsche_model`
- **Origem:** `string`. **Alvo:** `string` padronizada.
- **Estado:** relativamente limpo (`718 Cayman`, `911 Turbo S`, `Taycan 4S`, `Cayenne Coupe`...).
- **Regra:** apenas normalizar espaços/caixa. Opcional: derivar coluna `model_line` (família: 718 / 911 / Taycan / Panamera / Macan / Cayenne) para agregação no report.

### 3.5 `model_year`
- **Origem:** `int` e `string`. **Alvo:** `int` de 4 dígitos.
- **Problemas:** inteiros (`2020`–`2026`); por extenso (`twenty twenty four`, `two thousand twenty one`); com espaço (`20 23`, `20 24`); com hífen (`20-23`, `20-25`).
- **Regra:** normalizar todas as formas para inteiro. Mapeamento de extenso: `twenty twenty one`→2021 … `twenty twenty six`→2026; `two thousand twenty one`→2021. Para `20 23`/`20-23`, remover separador ⇒ `2023`. Validar faixa 2020–2026 (quarentena se fora).

### 3.6 `sale_price` ⚠️ *(segunda mais problemática — mistura formato US e europeu)*
- **Origem:** `string` e `int`. **Alvo:** `decimal` em USD (sem símbolo).
- **Problemas observados:**
  - US puro: `$79,500.00`, `$153,200.50`, `USD 58,900.00` (vírgula = milhar, ponto = decimal).
  - Europeu: `$89.750,00`, `$103.750,00`, `$121.750,00` (ponto = milhar, vírgula = decimal).
  - Milhar com ponto (EU) sem decimal: `USD 112.750` (=112 750), `68.900 dollars`, `USD 241.000`.
  - Sufixo `k`/`K`: `$121k`, `188k USD`, `$139k`, `$59k` (multiplicar por 1000).
  - Sem separador: `$132000`, inteiro puro `73500`.
  - Símbolos/rótulos variados: `$`, `USD`, `usd`, `dollars`, e combinações (`USD $96,300`).
- **Regra de parsing (ordem obrigatória):**
  1. Remover rótulos de moeda: `$`, `USD`, `usd`, `dollars`, `dollar` e espaços.
  2. Se terminar em `k`/`K`: remover o `k`, converter o número e **multiplicar por 1000**. Encerrar.
  3. Se tiver **ponto e vírgula**: o **separador mais à direita é o decimal**; o outro é milhar. Ex.: `89.750,00` ⇒ decimal é `,` ⇒ `89750.00`. `79,500.00` ⇒ decimal é `.` ⇒ `79500.00`.
  4. Se tiver **só vírgula**: 3 dígitos após ⇒ milhar (`104,500`→104500); 2 dígitos após ⇒ decimal.
  5. Se tiver **só ponto**: 3 dígitos após ⇒ milhar EU (`112.750`→112750); 2 dígitos após ⇒ decimal (`153200.50`).
  6. **Sanity check final:** o valor tem que cair na faixa plausível **US$ 30.000 – US$ 400.000**. Se o parsing produzir algo fora (ex.: `112.75`), reinterprete o separador; se ainda assim ficar fora, quarentena com motivo `preco_ambiguo`.

### 3.7 `vehicle_mileage` ⚠️
- **Origem:** `string` e `int`. **Alvo:** `int` de milhas + flag de suspeita.
- **Problemas observados:**
  - Com "miles"/"mi"/"mi.": `9,800 miles`, `900 mi`, `19,250 mi.`, `41,000mi`, `7,800mi`.
  - Milhar europeu com ponto: `1.200 mi` (=1200), `33.700 miles`, `6.250 miles`.
  - Prefixo rótulo: `Miles: 6,400`, `Miles 4,200`.
  - **Unidade diferente — quilômetros:** `KM 18,900`, `KM 10,900`, `KM 9,450`. Isso **não** é milha.
  - Textual/zero: `zero miles`, `zero`, `new`, `new car`, `0 miles` ⇒ 0.
  - Por extenso: `twelve thousand miles` (=12000), `fifteen thousand miles`.
  - Inteiros puros baixos e suspeitos: `28`, `11`, `9.5` — improváveis como milhas reais de um carro à venda.
- **Regra de transformação:**
  1. `zero`/`new`/`new car`/`zero miles` ⇒ `0`.
  2. Converter extenso (`twelve thousand`→12000).
  3. Remover rótulos (`Miles:`, `mi`, `miles`, `mi.`) e aplicar a mesma lógica de separadores do preço (ponto/vírgula de milhar).
  4. **KM:** normalizar para milhas (`milhas = km / 1.60934`) e **registrar** a conversão numa coluna `mileage_unit_raw = 'km'`. Não perca a informação de que a origem era km.
  5. **Suspeitos:** valores brutos `< 100` sem contexto (`28`, `11`, `9.5`) ⇒ manter o valor mas setar flag `mileage_suspect = true` para revisão no report (podem ser dígitos truncados ou erro de digitação).

### 3.8 `payment_method`
- **Origem:** `string`. **Alvo:** categoria canônica (enum).
- **Problema:** 32 variações de caixa/espaço/hífen/underscore para poucas categorias reais.
- **Mapa canônico (aplicar após lowercase + trim):**

  | Categoria canônica | Variações observadas |
  |---|---|
  | `cash` | cash, CASH, cash payment, CASH payment |
  | `credit_card` | Credit card, Credit Card, CreditCard, credit, credit card payment |
  | `debit_card` | debit card |
  | `bank_transfer` | Bank Transfer, bank transfer, bank-transfer, bank_transfer, Bank wire, bank wire, wire, wire transfer, Wire Transfer, WireTransfer, wire-transfer, ACH payment |
  | `financing` | Financing, Financing Plan, Financing plan, finance |
  | `lease` | lease, Leasing, lease plan |
  | `crypto` | Crypto, crypto, crypto payment |

  > **Decisão a confirmar com o usuário:** agrupei `wire`/`bank wire`/`ACH` todos em `bank_transfer`. Se o report precisar distinguir *wire* de *ACH* de *bank transfer*, quebrar em subcategorias. Qualquer valor não mapeado ⇒ `other` + log.

### 3.9 `city`
- **Origem:** `string`. **Alvo:** Title Case.
- **Problema:** caixa inconsistente (`boston`, `los angeles`, `new york` vs `Seattle`).
- **Regra:** Title Case. Cuidado com abreviações internas (ex.: `St. Louis` deve manter o `St.`).

### 3.10 `state`
- **Origem:** `string`. **Alvo:** sigla USPS de 2 letras, maiúscula.
- **Problema:** mistura nome completo e sigla, caixa inconsistente (`ma`, `Washington`, `tx`, `California`, `TX`, `New York`).
- **Regra:** mapear nome completo → sigla USPS e uppercase das siglas. Ex.: `Washington`→`WA`, `California`/`ca`→`CA`, `tx`/`Texas`→`TX`, `North Carolina`→`NC`. Validar contra a lista oficial de 50 estados; não mapeado ⇒ quarentena `estado_invalido`.

### 3.11 `salesperson`
- **Origem:** `string`. **Alvo:** Title Case.
- **Problema:** caixa inconsistente (`kevin`, `AMANDA scott`, `LISA ray`); granularidade mista (alguns só primeiro nome — `kevin`, `jessica`, `natalie` — outros nome completo).
- **Regra:** Title Case. **Não** completar nomes. Se o report exigir vendedor único por pessoa, sinalizar que registros só-com-primeiro-nome não são desambiguáveis com segurança.

### 3.12 `delivery_status`
- **Origem:** `string`. **Alvo:** categoria canônica (enum).
- **Problema:** 22 variações — caixa, pontuação (`delivered!!!`, `delivered.`, `pending!!`), typo (`DELIVERD`).
- **Mapa canônico (aplicar após lowercase + trim + remover pontuação final):**

  | Categoria canônica | Variações observadas |
  |---|---|
  | `delivered` | delivered, DELIVERED, Delivered, delivered!!!, delivered., **DELIVERD** (typo) |
  | `in_transit` | in transit, In Transit, in Transit, IN TRANSIT, in-transit, shipped |
  | `pending` | pending, Pending, pending approval, pending review, pending!!, awaiting review |
  | `awaiting` | awaiting delivery, awaiting pickup |
  | `cancelled` | cancelled, CANCELLED |

  > **Decisões a confirmar:** (a) juntei `shipped` em `in_transit`; (b) separei `awaiting delivery/pickup` de `pending` — se o negócio tratar como mesma coisa, unir. Qualquer valor novo ⇒ `unknown` + log.

---

## 4. Schema final (tabela limpa)

| Coluna | Tipo | Notas |
|---|---|---|
| `sale_id` | `int` | PK, único |
| `sale_date` | `date` | ISO `YYYY-MM-DD`; `null` se inválida |
| `customer_name` | `string` | Title Case |
| `porsche_model` | `string` | normalizado |
| `model_line` | `string` | *derivado* (718/911/Taycan/Panamera/Macan/Cayenne) |
| `model_year` | `int` | 2020–2026 |
| `sale_price_usd` | `decimal(12,2)` | USD, sem símbolo |
| `mileage_miles` | `int` | em milhas (km convertido) |
| `mileage_unit_raw` | `string` | `miles`/`km` (origem) |
| `mileage_suspect` | `bool` | true se valor bruto implausível |
| `payment_method` | `enum` | ver §3.8 |
| `city` | `string` | Title Case |
| `state` | `string(2)` | sigla USPS |
| `salesperson` | `string` | Title Case |
| `delivery_status` | `enum` | ver §3.12 |

---

## 5. Validações que o agente deve rodar e reportar

1. **Unicidade/nulos** em `sale_id`.
2. **% de datas** parseadas com sucesso vs quarentenadas (motivo).
3. **`sale_price_usd`** dentro de 30k–400k; listar outliers.
4. **`model_year`** em 2020–2026.
5. **`state`** ∈ lista oficial de 50 estados.
6. **Cardinalidade final** de `payment_method` e `delivery_status` (confirmar que colapsou nas categorias esperadas, sem `other`/`unknown` inesperados).
7. **Contagem `mileage_suspect = true`** para revisão manual.
8. Relatório de limpeza: linhas totais, linhas 100% limpas, linhas com ≥1 campo quarentenado, campos afetados por coluna.

---

## 6. Tabela de quarentena (`quarantine`)

Para cada campo irrecuperável, gerar uma linha:

| Campo | Descrição |
|---|---|
| `sale_id` | id da venda afetada |
| `column` | coluna problemática (ex.: `sale_date`) |
| `raw_value` | valor bruto original |
| `reason` | `data_invalida` / `data_fora_de_faixa` / `preco_ambiguo` / `estado_invalido` / `model_year_invalido` / `categoria_desconhecida` |

**Princípio:** quarentena zera **só o campo**, não a linha. A venda continua na base limpa com os demais campos tratados. Nada de "adivinhar" — data 30/02 vira `null` + registro na quarentena, ponto.

---

## 7. Ordem de execução sugerida para o agente

1. Ler a aba, aplicar trim/limpeza de caracteres invisíveis em todo texto (§2.4).
2. Validar `sale_id`.
3. Processar colunas categóricas com mapa fixo (`payment_method`, `delivery_status`, `state`) — mais determinístico, ganha confiança cedo.
4. Normalizar `model_year`, `customer_name`, `city`, `salesperson`, `porsche_model` (+ derivar `model_line`).
5. Parsear `sale_price` e `vehicle_mileage` com as regras de separador + sanity check.
6. Parsear `sale_date` por último (mais complexo), com validação de calendário e quarentena.
7. Rodar validações §5, gerar `quarantine` §6 e o relatório de limpeza.
8. Só então liberar a base limpa para o report.
